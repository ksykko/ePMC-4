Success
<a href="<?= site_url('Login/logout'); ?>">Logout</a>