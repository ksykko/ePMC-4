
<script type="module" src="<?= base_url('/assets/js/database.js') ?>"></script>

<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js'></script>
<script src="<?= base_url('/assets/js/website-scripts.js') ?>"></script>
<script src="<?= base_url('/assets/js/dashboard-header.js') ?>"></script>
<script src="https://account.snatchbot.me/script.js"></script>
<script>
    window.sntchChat.Init(270244)
</script>


</body>

</html>